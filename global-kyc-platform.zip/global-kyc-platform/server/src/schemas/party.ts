import { z } from 'zod';
export const PartySchema = z.object({
  legalName: z.string(),
  type: z.string(),
});