import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import pino from 'pino';
import pinoHttp from 'pino-http';
import { auth } from './middleware/auth.js';
import { errorHandler, notFound } from './middleware/error.js';
import parties from './routes/parties.js';
import screening from './routes/screening.js';
import documents from './routes/documents.js';
import risk from './routes/risk.js';
import workflows from './routes/workflows.js';
import audit from './routes/audit.js';

const app = express();
const logger = pino({ level: process.env.NODE_ENV === 'production' ? 'info' : 'debug' });

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined'));
app.use(pinoHttp({ logger }));

// Plug auth middleware (no-op if envs missing)
app.use(auth);

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/api/parties', parties);
app.use('/api/screening', screening);
app.use('/api/documents', documents);
app.use('/api/risk', risk);
app.use('/api/workflows', workflows);
app.use('/api/audit', audit);

app.use(notFound);
app.use(errorHandler);

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(`API listening on :${port}`);
});
