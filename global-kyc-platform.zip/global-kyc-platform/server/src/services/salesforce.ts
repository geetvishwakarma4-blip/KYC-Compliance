import fs from 'fs/promises';

export async function uploadToSalesforce({ path, filename, title }:{ path:string, filename:string, title:string }){
  // STUB: Replace with OAuth + ContentVersion create
  const buf = await fs.readFile(path);
  const base64 = buf.toString('base64');
  // simulate returning an ID
  return { contentVersionId: '068xxxxxxxxxxxx', _raw: { uploadedBytes: base64.length, filename, title } };
}
