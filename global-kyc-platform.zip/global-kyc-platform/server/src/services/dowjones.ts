export async function runDowJonesScreen({ name, countries }:{ name:string, countries:string[] }){
  // STUB: Replace with real HTTP call to DJ RC. This returns a normalized result.
  const fakeHit = name.toLowerCase().includes('test') ? ['AdverseMedia'] : [];
  const decision = fakeHit.length ? 'Review' : 'Clear';
  const resultHash = Buffer.from(name).toString('base64').slice(0,16);
  return { resultHash, riskTags: fakeHit, pdfReportSfFileId: null, decision, _raw: { name, countries, decision } };
}
