import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const r = Router();

r.post('/:id/submit', async (req, res, next) => {
  try {
    const wf = await prisma.workflow.upsert({
      where: { id: req.params.id },
      update: { state: 'Submitted', submittedAt: new Date() },
      create: { id: req.params.id, partyId: req.body.partyId, state: 'Submitted', submittedAt: new Date() }
    });
    res.json(wf);
  } catch (e) { next(e); }
});

r.post('/:id/approve', async (req, res, next) => {
  try {
    const wf = await prisma.workflow.update({ where: { id: req.params.id }, data: { state: 'Approved', decidedAt: new Date() } });
    res.json(wf);
  } catch (e) { next(e); }
});

r.post('/:id/reject', async (req, res, next) => {
  try {
    const wf = await prisma.workflow.update({ where: { id: req.params.id }, data: { state: 'Rejected', decidedAt: new Date() } });
    res.json(wf);
  } catch (e) { next(e); }
});

export default r;
