import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
import { uploadToSalesforce } from '../services/salesforce.js';

const prisma = new PrismaClient();
const r = Router();
const upload = multer({ dest: '/tmp', limits: { fileSize: 15 * 1024 * 1024 } });

r.post('/upload', upload.single('file'), async (req, res, next) => {
  try {
    const Q = z.object({
      partyId: z.string(),
      doctype: z.string()
    }).parse(req.query);

    if (!req.file) throw new Error('file required');

    // TODO: AV scan + MIME enforcement here.
    const sf = await uploadToSalesforce({ path: req.file.path, filename: req.file.originalname, title: Q.doctype });

    const doc = await prisma.document.create({
      data: {
        partyId: Q.partyId,
        docType: Q.doctype,
        sfFileId: sf.contentVersionId,
        status: 'Received',
        receivedOn: new Date()
      }
    });
    res.status(201).json(doc);
  } catch (e) { next(e); }
});

export default r;
