import { Router } from 'express';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const r = Router();

const RiskSchema = z.object({
  partyId: z.string(),
  score: z.number().min(0).max(100),
  level: z.enum(['Low','Medium','High']),
  factors: z.record(z.any())
});

r.post('/assessments', async (req, res, next) => {
  try {
    const body = RiskSchema.parse(req.body);
    const ra = await prisma.riskAssessment.create({ data: {
      partyId: body.partyId,
      score: body.score,
      level: body.level,
      factorsJson: JSON.stringify(body.factors)
    }});
    res.status(201).json(ra);
  } catch (e) { next(e); }
});

export default r;
