import { Router } from 'express';
const r = Router();

// Placeholder: in prod, use append-only store with hashing
r.get('/', async (_req, res) => {
  res.json([{ when: new Date().toISOString(), actor: 'demo.user', action: 'CREATE', entity: 'Party', id: '#DEMO' }]);
});

export default r;
