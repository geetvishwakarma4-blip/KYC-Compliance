import { Router } from 'express';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const r = Router();

const PartySchema = z.object({
  legalName: z.string(),
  tradingName: z.string().optional(),
  type: z.string(),
  incorpNumber: z.string().optional(),
  incorpCountry: z.string().optional(),
  lei: z.string().optional(),
  website: z.string().url().optional(),
  complianceEmail: z.string().email().optional(),
  address: z.string().optional(),
  taxIds: z.string().optional(),
  phone: z.string().optional(),
  status: z.string().optional()
});

r.post('/', async (req, res, next) => {
  try {
    const body = PartySchema.parse(req.body);
    const created = await prisma.party.create({ data: body });
    res.status(201).json(created);
  } catch (e) { next(e); }
});

r.put('/:id', async (req, res, next) => {
  try {
    const body = PartySchema.partial().parse(req.body);
    const updated = await prisma.party.update({ where: { id: req.params.id }, data: body });
    res.json(updated);
  } catch (e) { next(e); }
});

r.post('/:id/ubos', async (req, res, next) => {
  try {
    const PersonSchema = z.object({
      fullName: z.string(),
      dob: z.string().optional(),
      nationality: z.string().optional(),
      address: z.string().optional(),
      aliases: z.string().optional(),
      pepStatus: z.string().optional(),
      ownershipPct: z.number().optional(),
      controlType: z.string().optional()
    });
    const body = PersonSchema.parse(req.body);
    const person = await prisma.person.create({ data: {
      fullName: body.fullName,
      dob: body.dob ? new Date(body.dob) : undefined,
      nationality: body.nationality,
      address: body.address,
      aliases: body.aliases,
      pepStatus: body.pepStatus
    }});
    const bo = await prisma.bO.create({ data: {
      partyId: req.params.id,
      personId: person.id,
      ownershipPct: body.ownershipPct,
      controlType: body.controlType
    }});
    res.status(201).json({ person, bo });
  } catch (e) { next(e); }
});

r.post('/:id/vessels', async (req, res, next) => {
  try {
    const VesselSchema = z.object({
      name: z.string().optional(),
      imo: z.string().optional(),
      mmsi: z.string().optional(),
      flag: z.string().optional(),
      classSociety: z.string().optional(),
      yearBuilt: z.number().optional(),
      type: z.string().optional()
    });
    const body = VesselSchema.parse(req.body);
    const v = await prisma.vessel.create({ data: { ...body, partyId: req.params.id }});
    res.status(201).json(v);
  } catch (e) { next(e); }
});

export default r;
