import { Router } from 'express';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';
import { runDowJonesScreen } from '../services/dowjones.js';
const prisma = new PrismaClient();
const r = Router();

const ScreenSchema = z.object({
  scope: z.enum(['party','ubos','vessels']).default('party'),
  names: z.array(z.object({ full: z.string() })).optional(),
  countries: z.array(z.string()).optional()
});

r.post('/party/:id', async (req, res, next) => {
  try {
    const body = ScreenSchema.parse(req.body || {});
    const party = await prisma.party.findUniqueOrThrow({ where: { id: req.params.id } });
    const subject = body.names?.[0]?.full || party.legalName;
    const result = await runDowJonesScreen({ name: subject, countries: body.countries || [] });
    const record = await prisma.screening.create({
      data: {
        partyId: party.id,
        provider: 'DowJones',
        query: JSON.stringify({ subject }),
        resultHash: result.resultHash,
        riskTags: (result.riskTags || []).join(','),
        pdfReportSfFileId: result.pdfReportSfFileId || null,
        decision: result.decision
      }
    });
    res.json({ record, providerResponse: result._raw });
  } catch (e) { next(e); }
});

export default r;
