import type { Request, Response, NextFunction } from 'express';

/**
 * Placeholder for JWT/OIDC validation.
 * In production, validate JWT audience/issuer and verify via JWKS.
 */
export function auth(req: Request, res: Response, next: NextFunction) {
  // Allow /health and local dev without token
  if (req.path === '/health' || process.env.NODE_ENV !== 'production') return next();
  const hdr = req.headers.authorization || '';
  if (!hdr.startsWith('Bearer ')) return res.status(401).json({ error: 'missing bearer token' });
  // TODO: verify JWT
  return next();
}
