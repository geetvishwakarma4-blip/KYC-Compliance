# Global KYC — Shipping (React + Node/Express + Prisma)

Production-ready boilerplate for a global KYC & document-upload platform for shipping companies, with Salesforce (document store) and Dow Jones (screening) integration stubs.

## Stack
- **Client:** React + Vite (TypeScript)
- **Server:** Node + Express (TypeScript)
- **DB:** PostgreSQL (Prisma ORM)
- **Auth:** OIDC-ready middleware stub (JWT bearer expected)
- **Vendors:** Salesforce Files (ContentVersion) + Dow Jones Risk & Compliance (stubs)
- **Infra:** Docker Compose for local dev

## Quickstart
1) Create `.env` files from `.env.example` in `/server` and set secrets.
2) Start database and services:
```bash
docker compose up -d db
```
3) Install deps and run migrations:
```bash
cd server
npm i
npx prisma migrate dev
npm run dev
```
4) Run client:
```bash
cd ../client
npm i
npm run dev
```
Client runs on http://localhost:5173, API on http://localhost:3001.

## Postman
Import `postman/Global-KYC.postman_collection.json` and use the pre-defined requests.

## Security Notes
- AV scan + MIME/extension check enforced on uploads.
- JWT expected on `Authorization: Bearer <token>` (replace with your IdP).
- Sanitize/validate all inputs; JSON Schemas included.
- Replace vendor stubs with real API calls; store secrets in a vault in production.
