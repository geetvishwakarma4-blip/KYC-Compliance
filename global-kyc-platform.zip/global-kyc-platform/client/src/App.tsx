import React, { useState } from 'react'

const TABS = ['Onboarding','Party Profile','UBOs','Vessels','Operations','Documents','Screening','Risk','Approvals','Audit','Admin'] as const
type Tab = typeof TABS[number]

export default function App(){
  const [tab,setTab] = useState<Tab>('Onboarding')
  return (
    <>
      <header>
        <div className="wrap">
          <h1>Global KYC — Shipping</h1>
          <div className="tabs">
            {TABS.map(t => (
              <button key={t} className={'tab'+(t===tab?' active':'')} onClick={()=>setTab(t)}>{t}</button>
            ))}
          </div>
        </div>
      </header>
      <main className="wrap">
        {tab==='Onboarding' && <Onboarding />}
        {tab==='Party Profile' && <PartyProfile />}
        {tab==='UBOs' && <div>UBO form goes here</div>}
        {tab==='Vessels' && <div>Vessel form goes here</div>}
        {tab==='Operations' && <div>Operations form goes here</div>}
        {tab==='Documents' && <div>Document upload goes here</div>}
        {tab==='Screening' && <div>Screening panel goes here</div>}
        {tab==='Risk' && <div>Risk assessment goes here</div>}
        {tab==='Approvals' && <div>Approvals flow goes here</div>}
        {tab==='Audit' && <div>Audit log goes here</div>}
        {tab==='Admin' && <div>Admin config goes here</div>}
      </main>
    </>
  )
}

function Onboarding(){
  const [form,setForm] = useState({ legalName:'', type:'Owner', incorpCountry:'', lei:'', website:'', complianceEmail:'' })
  async function save(){
    const res = await fetch('http://localhost:3001/api/parties', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(form) })
    if(!res.ok){ alert('Failed'); return }
    const data = await res.json()
    alert('Created party: '+data.id)
  }
  return (
    <div>
      <h3>Create Case</h3>
      <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:12}}>
        <label>Legal Name <input value={form.legalName} onChange={e=>setForm({...form, legalName:e.target.value})} /></label>
        <label>Party Type
          <select value={form.type} onChange={e=>setForm({...form, type:e.target.value})}>
            {['Owner','Operator','Charterer','Agent','Broker','Bunker','NVOCC','Other'].map(o=><option key={o}>{o}</option>)}
          </select>
        </label>
        <label>Incorp Country <input value={form.incorpCountry} onChange={e=>setForm({...form, incorpCountry:e.target.value})} /></label>
        <label>LEI <input value={form.lei} onChange={e=>setForm({...form, lei:e.target.value})} /></label>
        <label>Website <input value={form.website} onChange={e=>setForm({...form, website:e.target.value})} /></label>
        <label>Compliance Email <input value={form.complianceEmail} onChange={e=>setForm({...form, complianceEmail:e.target.value})} /></label>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={save}>Save</button>
      </div>
    </div>
  )
}

function PartyProfile(){
  return <div><h3>Party Profile (KYB)</h3><p>Extend with full KYC questionnaire as needed.</p></div>
}
